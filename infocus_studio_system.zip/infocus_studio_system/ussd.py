from flask import Flask
from flask_ussd import USSD

app = Flask(__name__)
ussd = USSD(app)

# Initialize some session data
sessions = {}

# USSD main menu
@ussd.route('/')
def main_menu():
    return "Welcome to Infocus Studio. Choose an option:\n1. Register\n2. Order Photography\n3. Order Videography"

# Register menu
@ussd.route('/register')
def register_menu():
    return "Please enter your name:"

@ussd.route('/register/<name>')
def register(name):
    # Save user's name to session
    sessions[ussd.msisdn] = {'name': name}
    return "Registration successful! Your name is {}".format(name)

# Order photography menu
@ussd.route('/order/photography')
def order_photography_menu():
    if ussd.msisdn in sessions:
        return "Please enter the date for photography (YYYY-MM-DD):"
    else:
        return "You need to register first. Please choose option 1 to register."

@ussd.route('/order/photography/<date>')
def order_photography(date):
    if ussd.msisdn in sessions:
        # Process order and save to database
        return "Photography order for {} placed successfully!".format(date)
    else:
        return "You need to register first. Please choose option 1 to register."

# Order videography menu
@ussd.route('/order/videography')
def order_videography_menu():
    if ussd.msisdn in sessions:
        return "Please enter the date for videography (YYYY-MM-DD):"
    else:
        return "You need to register first. Please choose option 1 to register."

@ussd.route('/order/videography/<date>')
def order_videography(date):
    if ussd.msisdn in sessions:
        # Process order and save to database
        return "Videography order for {} placed successfully!".format(date)
    else:
        return "You need to register first. Please choose option 1 to register."

if __name__ == '__main__':
    app.run(debug=True)
